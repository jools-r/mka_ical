<?php
$a=2;switch($a){case 1:echo 1;case 2:echo 2;case'a':echo'a';default:echo'default';}