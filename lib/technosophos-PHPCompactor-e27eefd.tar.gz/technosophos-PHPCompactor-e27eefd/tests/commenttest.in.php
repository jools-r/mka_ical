<?php

 /**
  * TEST COMMENT
  **///TEST COMMENT
  ///TEST COMMENT
  /**//*//*/echo /**
  * TEST COMMENT
  **///TEST COMMENT
  ///TEST COMMENT
  /**//*//*/1/**
   * TEST COMMENT
   **///TEST COMMENT
   ///TEST COMMENT
   /**//*//*/;
