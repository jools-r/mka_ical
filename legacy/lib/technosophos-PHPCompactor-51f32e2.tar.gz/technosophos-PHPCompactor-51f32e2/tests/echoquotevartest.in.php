<?php
$a  =           '2' ;
echo 'a' ;
echo "$a" ;
echo "a" ;
echo " $a?" ;
echo "${a}" ;
print $a;